## Обложка в стиле Audi Navigation RNS-D
![prototype scheme](https://github.com/maltsevvv/skin.rnsd/blob/main/resources/icon.png)
![prototype scheme](https://github.com/maltsevvv/skin.rnsd/blob/main/resources/list.png)
![prototype scheme](https://github.com/maltsevvv/skin.rnsd/blob/main/resources/music.png)


### Auto Install

1. Записать на sd-карту с образом Raspbian Buster Lite
2. Подключиться по SSH 
3. login: `pi` 
password: `rpi`

```
wget -P /tmp https://raw.githubusercontent.com/maltsevvv/maltsev-Kodi-Repo/master/autoinstall.sh
sudo sh /tmp/autoinstall.sh
```
