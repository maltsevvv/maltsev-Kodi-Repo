#!/usr/bin/env python

from __future__ import print_function
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import sys
import datetime
import subprocess
import re
import time
import threading
import string

from sendcan import sendcan
from tvtuner import tvtuner
from dumpcan import dumpcan
from bluetooth import a2dpinfo
from minors import logcan
from time import strftime, localtime, sleep
from threading import Thread, Timer

sd_write = xbmcgui.ControlLabel(300, 30, 70, 60, 'SD', '50', '0xFFB22222')
sd_read = xbmcgui.ControlLabel(300, 30, 70, 60, 'SD', '50', '0xFF22B26A')

def sd():
    cmd = "df -h | awk '$NF==\"/\"{printf $1}'"
    sd = subprocess.check_output(cmd, shell = True).decode("utf-8")
    sd = str(sd)
    xbmcgui.Window(10000).setProperty('sd', sd)
    if sd == '/dev/root':
        xbmcgui.Window(10000).setProperty('sd_write', sd)
        xbmcgui.Window(10000).addControl(sd_write)
    elif sd == 'overlay':
        xbmcgui.Window(10000).setProperty('sd_read', sd)
        xbmcgui.Window(10000).addControl(sd_read)
    while True:
        sd_overlay = xbmcgui.Window(10000).getProperty('sd_overlay')
        if sd == '/dev/root' and sd_overlay == 'true':
            xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
            os.system('sudo raspi-config nonint enable_overlayfs && sudo reboot')
        elif sd == 'overlay' and sd_overlay == 'false':
            xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
            os.system('sudo raspi-config nonint disable_overlayfs && sudo reboot')
        time.sleep(1)

def changelog():
    path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")
    logfile = xbmcvfs.File(os.path.join(path, 'changelog.txt'))
    text = logfile.read()
    logfile.close()
    dialog = xbmcgui.Dialog()
    dialog.textviewer(xbmc.getLocalizedString(24036), text)

if __name__ == '__main__':
    xbmc.executebuiltin('ActivateWindow(Home)')
    Thread(target = dumpcan).start()
    Thread(target = sd).start()
    Thread(target = tvtuner).start()
    Thread(target = sendcan).start()
    Thread(target = a2dpinfo).start()
    #Thread(target = changelog).start()
    Thread(target = logcan).start()
    
