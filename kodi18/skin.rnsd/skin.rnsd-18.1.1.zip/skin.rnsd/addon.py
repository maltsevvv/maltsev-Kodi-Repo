#!/usr/bin/env python

from __future__ import print_function
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import datetime
import subprocess
import re
import time
import threading
import string

from tvtuner import tvtuner
from dumpcan import dumpcan
from bluetooth import get_info, get_control
from time import strftime, localtime, sleep
from threading import Thread, Timer

sd_write = xbmcgui.ControlLabel(300, 30, 70, 60, 'SD', '50', '0xFFB22222')
sd_read = xbmcgui.ControlLabel(300, 30, 70, 60, 'SD', '50', '0xFF22B26A')

def sd():
    cmd = "df -h | awk '$NF==\"/\"{printf $1}'"
    sd = subprocess.check_output(cmd, shell = True).decode("utf-8")
    sd = str(sd)
    xbmcgui.Window(10000).setProperty('sd', sd)
    if sd == '/dev/root':
        xbmcgui.Window(10000).setProperty('sd_write', sd)
        xbmcgui.Window(10000).addControl(sd_write)
    elif sd == 'overlay':
        xbmcgui.Window(10000).setProperty('sd_read', sd)
        xbmcgui.Window(10000).addControl(sd_read)
    while True:
        sd_overlay = xbmcgui.Window(10000).getProperty('sd_overlay')
        if sd == '/dev/root' and sd_overlay == 'true':
            xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
            os.system('sudo raspi-config nonint enable_overlayfs && sudo reboot')
        elif sd == 'overlay' and sd_overlay == 'false':
            xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
            os.system('sudo raspi-config nonint disable_overlayfs && sudo reboot')
        time.sleep(1)


# def rpi_cpu():
        # cmd = 'vcgencmd measure_temp'
        # cpu_temp = subprocess.check_output(cmd, shell=True).decode("utf8")
        # cpu_temp = str(cpu_temp[5:9])
        # xbmcgui.Window(10000).setProperty('rpi_cpu', str(cpu_temp))
        # sleep(10)
        # rpi_cpu()

if __name__ == '__main__':
    xbmc.executebuiltin('ActivateWindow(Home)')
    Thread(target = dumpcan).start()
    Thread(target = sd).start()
    Thread(target = tvtuner).start()
    Thread(target = get_info).start()
    Thread(target = get_control).start()
    # Thread(target = rpi_cpu).start()