#!/usr/bin/env python

import time
import xbmc
import xbmcgui
import re
import os 
import sys
import datetime
import subprocess
import binascii
import string
import can
from subprocess import check_output, call
bus = can.Bus(interface='socketcan', channel='can0', receive_own_messages=True)
bt_status = subprocess.call(["systemctl", "is-active", "--quiet", "bluetooth"])

def get_mac():
    if(bt_status == 0):  # if 0 (active), print "Active"
        while True:
            try:
                result = subprocess.check_output(["hcitool", "con",])
                result = result.decode()
                mac = re.search('(\w+):(\w+):(\w+):(\w+):(\w+):(\w+)', result).group(0)
                if xbmc.Player().isPlaying():
                    xbmc.executebuiltin('XBMC.PlayerControl(Stop)')
                    xbmc.executebuiltin('xbmc.activatewindow(10000)')
                return mac.replace(':', '_')
            #except subprocess.CalledProcessError as e:
            except: # subprocess.CalledProcessError:
                #print e.output
                xbmcgui.Window(10000).clearProperty('artist')
                xbmcgui.Window(10000).clearProperty('track')
                xbmcgui.Window(10000).clearProperty('title')
                xbmcgui.Window(10000).clearProperty('device')
                time.sleep(5)
                get_mac()

def get_info():
    if(bt_status == 0):  # if 0 (active), print "Active"
        while True:
            try:
                info_cmd = 'sudo dbus-send --system --type=method_call --print-reply --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.freedesktop.DBus.Properties.Get string:org.bluez.MediaPlayer1 string:Track'
                result = check_output(info_cmd, shell=True).decode("utf-8")
                regex = 'var.+string\s(.+)'
                name = 'title'
                title = re.findall(regex, result)[0]
                xbmcgui.Window(10000).setProperty(name, title[1:-1])
                name = 'artist'
                artist = re.findall(regex, result)[2]
                xbmcgui.Window(10000).setProperty(name, artist[1:-1])
                name = 'track'
                regex1 = 'var.+uint32\s(.+)'
                track = re.findall(regex1, result)[1]
                xbmcgui.Window(10000).setProperty(name, 'TRACK ' +  track)
                device_cmd = 'sudo bluetoothctl info'
                result = check_output(device_cmd, shell=True).decode("utf-8")
                regex1 = "Name:\s(.+)"
                name = 'device'
                device = re.findall(regex1, result)[0]
                xbmcgui.Window(10000).setProperty(name, device)
            except: # subprocess.CalledProcessError as e:
                # xbmcgui.Window(10000).clearProperty('artist')
                # xbmcgui.Window(10000).clearProperty('track')
                # xbmcgui.Window(10000).clearProperty('title')
                # xbmcgui.Window(10000).clearProperty('device')
                time.sleep(5)
                #get_info()

def get_control():
    if(bt_status == 0):  # if 0 (active), print "Active"
        left = 0
        right = 0
        for message in bus:
            canid = str(hex(message.arbitration_id).lstrip('0x').upper())
            msg = binascii.hexlify(message.data).decode('ascii').upper()
            if canid == '464':
                if msg[2:10] == '20010100': #Left
                    os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Previous')
                elif msg[2:10] == '20010300': #Right
                    os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Next')
                elif msg[2:10] == '20010050': #RETURN
                    os.system('sudo bluetoothctl disconnect')
            elif canid == '461':
                if msg == '373001010000': #PREVIOUS
                    if left == 1:
                        os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Previous')
                        left = 0
                    else:
                        left += 1
                elif msg == '373001020000': #NEXT
                    if right == 1:
                        os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Next')
                        right = 0
                    else:
                        right += 1
                elif msg == '373001000200': #RETURN
                    if back == 1:
                        os.system('sudo bluetoothctl disconnect')
                        back = 0
                    else:
                        back += 1
            elif canid == '5C3' or canid == '5C0':
                if msg == '3902': #UP
                    os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Next')
                elif msg == '3903': #DOWN
                    os.system('sudo dbus-send --system --type=method_call --dest=org.bluez /org/bluez/hci0/dev_'+get_mac()+'/player0 org.bluez.MediaPlayer1.Previous')
                elif msg == '3904': #Right
                    os.system('sudo bluetoothctl disconnect')